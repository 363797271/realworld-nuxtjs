import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _2cf1a5e4 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _576f607a = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _960c1df6 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _37689445 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _46ea0507 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _448f595e = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _1e32d792 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _2cf1a5e4,
    children: [{
      path: "",
      component: _576f607a,
      name: "home"
    }, {
      path: "login",
      component: _960c1df6,
      name: "login"
    }, {
      path: "register",
      component: _960c1df6,
      name: "register"
    }, {
      path: "profile/:username",
      component: _37689445,
      name: "profile"
    }, {
      path: "settings",
      component: _46ea0507,
      name: "settings"
    }, {
      path: "editor/:slug?",
      component: _448f595e,
      name: "editor"
    }, {
      path: "article/:slug",
      component: _1e32d792,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
